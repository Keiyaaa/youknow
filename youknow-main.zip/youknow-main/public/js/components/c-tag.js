class CTag extends HTMLDivElement{
    constructor(){
        super();
    }

    connectedCallback(){
        this.shadow = this.attachShadow({mode: 'open'});

        const text = this.getAttribute('text');

        const textElement = document.createElement('p');
        textElement.innerText = text;

        this.shadow.appendChild(textElement);
    }
}
customElements.define('c-tag', CTag, {extends: 'div'});