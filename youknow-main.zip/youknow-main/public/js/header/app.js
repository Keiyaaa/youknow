// .back-btnが押されたら、前のページに戻る
$(function () {
    $('.back-btn').on('click', function () {
        window.history.back();
    });
});
